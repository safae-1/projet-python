{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "4044eaba",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Entrez le nombre de termes:6\n",
      "Suite de Fibonacci en utilisant la recursion :\n",
      "0\n",
      "1\n",
      "1\n",
      "2\n",
      "3\n",
      "5\n"
     ]
    }
   ],
   "source": [
    "def fibonacci(n):\n",
    "\n",
    "    if(n <= 1):\n",
    "        return n\n",
    "    else:\n",
    "        return (fibonacci(n-1) + fibonacci(n-2))\n",
    "    \n",
    "n = int(input(\"Entrez le nombre de termes:\"))\n",
    "print(\"Suite de Fibonacci en utilisant la recursion :\")\n",
    "\n",
    "for i in range(n):\n",
    "    print(fibonacci(i))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2daa53c4",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.8"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
