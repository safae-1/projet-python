{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 29,
   "id": "d3ea7b12",
   "metadata": {},
   "outputs": [],
   "source": [
    "def Polynome(x): #definition de la fonction\n",
    "    return (x**3)-(1.5*x**2)-(6*x)+5\n",
    "  "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 30,
   "id": "73b7afb3",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "62.5"
      ]
     },
     "execution_count": 30,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "Polynome(5)"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.8"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
