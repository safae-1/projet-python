{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "a276cf9a",
   "metadata": {},
   "outputs": [],
   "source": [
    "def Polynome(x): #definition de la fonction\n",
    "    while True:\n",
    "        try:\n",
    "            x = input(\"Entrez le nombre de termes:\") #demander au utilusateur la valeur d'entree\n",
    "            if('j' in x):\n",
    "                print(\"valid number, pas un complexe!!\")#gerer l'exception du nombre complexe\n",
    "            x=float(x)\n",
    "        except ValueError:\n",
    "            if (type(x)==str):\n",
    "                print(\"valid number, pas un string!!\")#gerer l'exception de chaine de caractere \n",
    "            print('SVP entrer n int or float ')   \n",
    "            continue\n",
    "        if 0.5<=x<=100:\n",
    "            break\n",
    "        elif 0<=x<=0.5:\n",
    "            print('entrez un nombre compris entre 0.5 et 100')#gerer l'exception des petits nombres \n",
    "        elif x<0:\n",
    "            print('entre un nombre positif svp')# gerer l'exception du nombre negatif\n",
    "        elif x>100:\n",
    "            print('entrez un nombre compris entre 0.5 et 100')#gerer l'exception des grands nombre\n",
    "            \n",
    "    f=(x**3)-(1.5*x**2)-(6*x)+5\n",
    "    return f"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "41fcec93",
   "metadata": {},
   "outputs": [],
   "source": [
    "Polynome(5)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "6f87214c",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.8"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
