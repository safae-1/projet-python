{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 23,
   "id": "814da792",
   "metadata": {},
   "outputs": [],
   "source": [
    "import numpy as np\n",
    "import math\n",
    "\n",
    "\n",
    "\n",
    "N = norm.cdf\n",
    "\n",
    "def BS_CALL(S, K, T, r, sigma):\n",
    "    d1 = (np.log(S/K) + (r + sigma**2/2)*T) / (sigma*np.sqrt(T))\n",
    "    d2 = d1 - sigma * np.sqrt(T)\n",
    "    return S * N(d1) - K * np.exp(-r*T)* N(d2)\n",
    "\n",
    "def BS_PUT(S, K, T, r, sigma):\n",
    "    d1 = (np.log(S/K) + (r + sigma**2/2)*T) / (sigma*np.sqrt(T))\n",
    "    d2 = d1 - sigma* np.sqrt(T)\n",
    "    return K*np.exp(-r*T)*N(-d2) - S*N(-d1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 24,
   "id": "e08307be",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.999999975983479"
      ]
     },
     "execution_count": 24,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "BS_CALL(1,2,3,4,5)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 25,
   "id": "6b5c6421",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "1.2264408185646118e-05"
      ]
     },
     "execution_count": 25,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "BS_PUT(1,2,3,4,5)"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.8"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
