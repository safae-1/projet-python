{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 11,
   "id": "7c56412e",
   "metadata": {},
   "outputs": [],
   "source": [
    "def factorielle(n):\n",
    "    if n == 0:\n",
    "        return 1\n",
    "    else:\n",
    "        F = 1\n",
    "        for k in range(2,n+1):\n",
    "            F = F * k\n",
    "        return F"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 12,
   "id": "a3627a1e",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "120"
      ]
     },
     "execution_count": 12,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "factorielle(5)"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.8"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
